from flask import Flask, render_template, request, redirect, url_for, session
from openpyxl import load_workbook
import random
import os
import json
import sys, webbrowser, threading
# Dùng cho template
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS  # PyInstaller temp folder
    except:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)
# dùng cho lưu dữ liệu
def get_data_path():
    if getattr(sys, 'frozen',False):
        base_path = os.path.dirname(sys.executable)
    else:
        base_path = os.path.dirname(os.path.abspath(__file__)) #khi run python
    return os.path.join(base_path,"progress.json")

# load
def load_progress():
    try:
        with open("progress.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return []
# save
def save_progress(data):
    with open(get_data_path(), "w", encoding="utf-8") as f:
        json.dump(data, f,ensure_ascii=False, indent=2)

app = Flask(__name__, template_folder=resource_path('templates'))
app.secret_key = "123456"  #  bắt buộc cho session

def open_browser():
    webbrowser.open("http://127.0.0.1:5000")

vocab_list = []

@app.route('/', methods=['GET', 'POST'])
def index():
    global vocab_list

    if request.method == 'POST':
        file = request.files['file']

        if file:
            wb = load_workbook(file)
            ws = wb.active

            vocab_list = []

            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row:
                    continue

                vocab_list.append({
                    "hanzi": row[2],
                    "pinyin": row[3],
                    "meaning": row[4]
                })

            # 👉 reset dữ liệu đã học khi upload file mới
            #session['learned'] = []

            save_progress([])

    return render_template('index.html', count=len(vocab_list))

# Không hiện lại từ đã học, chỉ hiện từ chưa học
# 🔥 Flashcard (lọc từ chưa học)
@app.route('/flashcard')
def flashcard():
    if not vocab_list:
        return redirect(url_for('index'))

    #learned = session.get('learned', [])
    learned = load_progress()

    # 👉 lọc từ chưa học
    remaining = [i for i in range(len(vocab_list)) if i not in learned]

    if not remaining:
        return "🎉 Bạn đã học hết rồi!"

        #  lấy index theo danh sách remaining
    idx = request.args.get('idx', 0, type=int)

    #  giới hạn index
    if idx < 0:
        idx = 0
    if idx >= len(remaining):
        idx = len(remaining) - 1
    real_idx = remaining[idx] #map sang vocab_list

    word = vocab_list[real_idx]

    return render_template(
        'flashcard.html',
        word=word,
        idx=idx,
        real_idx=real_idx,
        learned_count=len(learned),
        total=len(vocab_list)
    )



# 🔥 Đánh dấu đã học
@app.route('/learned/<int:idx>')
def mark_learned(idx):
    #learned = session.get('learned', [])
    learned = load_progress()

    if idx not in learned:
        learned.append(idx)

    #session['learned'] = learned
    save_progress(learned)

    return redirect(url_for('flashcard',idx=idx + 1))

@app.route('/unlearn/<int:idx>')
def unlearn(idx):
    learned = load_progress()
    if idx in learned:
        learned.remove(idx)
    save_progress(learned)
    return redirect(url_for('vocab'))

# 🔥 Quiz
@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    if not vocab_list:
        return redirect(url_for('index'))

    if request.method == 'POST':
        answer = request.form['answer']
        correct = request.form['correct']

        result = (answer.strip() == correct.strip())

        return render_template('quiz.html', result=result)

    word = random.choice(vocab_list)
    return render_template('quiz.html', word=word)

@app.route('/vocab')
def vocab():
    if not vocab_list:
        return redirect(url_for('index'))

    #learned = session.get('learned', [])
    learned = load_progress()

    vocab_with_status = []

    for i, w in enumerate(vocab_list):
        vocab_with_status.append({
            "hanzi": w["hanzi"],
            "pinyin": w["pinyin"],
            "meaning": w["meaning"],
            "learned": i in learned,
            "idx": i
        })

    return render_template('vocab.html', vocab_list=vocab_with_status)

@app.route('/game')
def game():
    if not vocab_list:
        return redirect(url_for('index'))

    words = random.sample(vocab_list, min(5, len(vocab_list)))

    pairs = {w["hanzi"]: w["meaning"] for w in words}

    hanzi = list(pairs.keys())
    meanings = list(pairs.values())

    random.shuffle(meanings)

    return render_template(
        'game.html',
        hanzi=hanzi,
        meanings=meanings,
        pairs=pairs   # 👈 thêm cái này
    )

if __name__ == '__main__':
    threading.Timer(1.5,open_browser).start()
    #print("APPDATA:",os.getenv("APPDATA"))
    app.run(debug=True, use_reloader=False)